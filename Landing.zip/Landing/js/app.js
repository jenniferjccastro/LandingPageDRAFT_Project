/**
 * Manipulating the DOM exercise.
 * Programmatically builds navigation, scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * JS Version: ES2015/ES6
 * JS Standard: ESlint
*/

// Define Global Variables
const sections = document.querySelectorAll('section');
const navbar = document.querySelector('.navbar__menu');
let scrolling = false;
let cursor;

// Helper Functions

function findRange(section) {
    return {
        top: section.offsetTop - 100,
        end: section.offsetTop + section.offsetHeight - 100
    };
}

function inRange(curr, section) {
    const range = findRange(section);
    return curr >= range.top && curr <= range.end;
}

function navActive(target) {
    const navLink = document.querySelector(`a[href="#${target}"]`);
    if(document.querySelector('.current')) {
        document.querySelector('.current').classList.remove('current');
    }
    navLink.classList.add('current');
}

setInterval(function () {
    if(scrolling) {
        addClass(cursor);
        scrolling = false;
    }
}, 200);

// Main Functions

// Build the nav
const fragment = document.createDocumentFragment();

for(const section of sections) {
    const listElement = document.createElement('li');
    listElement.innerHTML = `<a href="#${section.id}" class="menu__link">${section.dataset.nav}</a>`;
    fragment.appendChild(listElement);
}

// Add class 'active' to section when near top of viewport and highlight nav link
function addClass(cursor) {
    for(const section of sections) {
        if(inRange(cursor, section)) {
            navActive(section.id);
            document.querySelector('.now-active')?.classList.remove('now-active');
            section.classList.add('now-active');
        }
    }
}

function smoothScroll(event) {
    event.preventDefault();
    const element = document.querySelector(`section${event.target.hash}`);
    scrollTo({
        top: element.offsetTop,
        left: 0,
        behavior: 'smooth'
    });
}

// Events

// Build menu
document.querySelector('#navbar__list').appendChild(fragment);

// Scroll to section on link click
navbar.addEventListener('click', smoothScroll);

// Set sections as active
document.addEventListener('scroll', function(event) {
    cursor = event.path[1].scrollY;
    scrolling = true;
});
